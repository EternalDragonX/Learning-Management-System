import * as API from './'

export default{

}